# showtime-mysql
database inspiration: https://github.com/csecsoliver/showtime-v2